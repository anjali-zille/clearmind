
import React ,{Component} from 'react';
import './App.css'
import {BrowserRouter as Router,Route,
 Switch} from 'react-router-dom'

//components
import Navbar from './components/Navbar';
import Footer from './components/footer'
import LandingPage  from './components/LandingPage'
import About from './components/About'



class App extends Component{
  render() {
    return(
     <Router> 
        <Navbar />
        <Switch>
          <Route path='/' exact component={LandingPage} />
          <Route path='/about' exact component={About}/>
          {/* <Route path='/contactus' exact component={Contact}/>  */}
        </Switch>
    
        {/* <LandingPage/> */}
       
        {/* <Footer/> */}
     </Router> 
   
        
    );
  }
}

export default App;
